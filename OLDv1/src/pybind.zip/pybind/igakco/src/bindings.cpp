#include <pybind11/pybind11.h>
#include "math.hpp"
#include "svm.hpp"

namespace py = pybind11;

PYBIND11_MODULE(igakco, m) {
    m.doc() = R"pbdoc(
        iGakco Python Plugin
        -----------------------

        .. currentmodule:: igakco

        .. autosummary::
           :toctree: _generate

           add
           subtract
    )pbdoc";

    m.def("add", &add, R"pbdoc(
        Add two numbers

        Some other explanation about the add function.
    )pbdoc");

    py::class_<SVM>(m, "SVM")
        .def(py::init<int, int, double, double, double>(), 
            py::arg("g"), py::arg("m"), py::arg("C")=1.0, 
            py::arg("nu")=0.5, py::arg("eps")=0.001)
        .def("toString", &SVM::toString)
        .def("fit", &SVM::fit, py::arg("train_file"), py::arg("dict")="", 
            py::arg("quiet")=false);

#ifdef VERSION_INFO
    m.attr("__version__") = VERSION_INFO;
#else
    m.attr("__version__") = "dev";
#endif
}

#ifndef READINPUT_H
#define READINPUT_H

#include <string>

int ** read_input(std::string filename, std::string dictFileName);

#endif
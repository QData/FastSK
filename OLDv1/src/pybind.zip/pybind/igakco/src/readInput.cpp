#include "readInput.h"

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <cstring>

// int * string_replace (const char *s, char *d, int seqLength);
// int help2();
// char * readDict (char *filename, int *na);

//int *seqLabels, int *seqLengths, long int *nStr, long int *maxlen, long int *minlen, int *dictionarySize

int** read_input(std::string filename, std::string dictFileName) {
    printf("Input file: %s\n", filename.c_str());
    if (!dictFileName.empty()) {
    	printf("Dictionary file: %s\n", filename.c_str());
    } else {
    	printf("No dictionary provided\n");
    }

    int **output;

    return output;
}
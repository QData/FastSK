#include "gakco_core.hpp"

#include <thread>
#include <vector>
#include <stdlib.h>
#include <cstdlib>

void do_work(int tid) {
	printf("Thread %d is doing work\n", tid);
}

double* construct_kernel() {
	double *K = (double *) malloc(100 * sizeof(double));
	memset(K, 0, 100 * sizeof(double));
	int max_m = 4;
	
	int num_threads = 4;
	std::vector<std::thread> threads;
	for (int i = 0; i < num_threads; i++) {
		threads.push_back(std::thread(&do_work, i));
	}
	for(auto &t : threads) {
		t.join();
	}
	return K;
}
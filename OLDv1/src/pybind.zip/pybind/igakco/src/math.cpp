#include "math.hpp"

int add(int i, int j) {
    return i + j;
}

int subtract(int i, int j) {
    return i - j;
}
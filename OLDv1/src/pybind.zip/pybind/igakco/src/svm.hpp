#ifndef GAKCOSVM_H
#define GAKCOSVM_H

#include <string>

class SVM {
public:
	// fields
	int g;
	int m;
	int k;
	int threads = -1;
	double C; //C param
	double nu; //nu for nu-SVC
	double cache_size = 100; // cache size
	double eps; //epsilon, tolernace of termination criteria
	int h = 1; //0 or 1, whether to use the shrinking heuristics
	double* kernel = NULL;
	double* test_kernel = NULL;
	long int nStr;
	long int nTestStr;
	int numClasses = -1;
	char *dictionary;
	bool quiet = false;

	// methods
	SVM(int g, int m, double C, double nu, double eps);
	void toString();
	void fit(std::string filename, std::string dict, bool quiet);
};

#endif
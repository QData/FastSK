#include "svm.hpp"
#include "gakco_core.hpp"
#include "dataset.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <cstring>

SVM::SVM(int g, int m, double C, double nu, double eps) {
	this->g = g;
	this->m = m;
	this->k = g - m;
	if (this->m > this->g) {
		printf("g must be greater than m\n");
		exit(1);
	}
	this->C = C;
	this->nu = nu;
	this->eps = eps;
}

void SVM::toString() {
	printf("g = %d, m = %d, C = %f, nu = %f, eps = %f, quiet = %d\n",
		this->g, this->m, this->C, this->nu, this->eps, this->quiet);
}

void SVM::fit(std::string train_file, std::string dict, bool quiet) {
	this->quiet = quiet;
	auto dataset = new Dataset(train_file, dict);
	dataset->collect_data();
	double* K = construct_kernel();
}
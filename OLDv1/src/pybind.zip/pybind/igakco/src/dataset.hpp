#ifndef DATASET_H
#define DATASET_H

#include <string>
#include "shared.h"

class Dataset {
public:
	std::string filename;
	std::string dictFileName;
	int dictionarySize;
	char *dict;
	int *seqLabels = (int *) malloc(MAXNSTR * sizeof(int));
	int *seqLengths = (int *) malloc(MAXNSTR * sizeof(int));
	long int nStr = MAXNSTR;
	long int maxlen = 0;
	long int minlen = STRMAXLEN;
	int **S;

	Dataset(std::string filename, std::string dictFileName);
	void collect_data();
	void readDict();
	void parseDict();
};

#endif
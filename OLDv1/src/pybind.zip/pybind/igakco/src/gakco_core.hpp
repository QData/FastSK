#ifndef GAKCO_CORE_H
#define GAKCO_CORE_H

void do_work(int tid);
double* construct_kernel();

#endif
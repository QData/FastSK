igakco Documentation
============================

Contents:

.. toctree::
   :maxdepth: 2

   igakco
